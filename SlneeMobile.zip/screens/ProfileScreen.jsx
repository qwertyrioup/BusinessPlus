import { useCallback, React } from "react";

import {
  Text,
  View,
  SafeAreaView,
  Pressable,
  Image,
  ScrollView,
  BackHandler,
} from "react-native";
import { useFonts } from "expo-font";
import * as SplashScreen from "expo-splash-screen";
import { Dimensions } from "react-native";
import Svg from "react-native-svg";
import { Path } from "react-native-svg";
import { useDispatch, useSelector } from "react-redux";
import { logout } from "../redux/userSlice";
import { deleteMenu } from "../redux/menuSlice";
import { deleteModule } from "../redux/moduleSlice";
import { deleteList } from "../redux/listSlice";
import { Button } from "react-native-paper";
import axios from "axios";
import { saveLang } from "../redux/languageSlice";
import { Alert } from "react-native-web";
import SelectDropdown from "react-native-select-dropdown";
import { useEffect } from "react";

SplashScreen.preventAutoHideAsync();

const DomainScreen = ({navigation}) => {
  const windowWidth = Dimensions.get("window").width;
  const windowHeight = Dimensions.get("window").height;
  const currentUser = useSelector((state) => state.user.currentUser);
  const currentDomain = useSelector((state) => state.domain.value);
  const lang = useSelector((state) => state.lang.value);
  const dispatch = useDispatch()
  const handleLogOut = async() => {
    try {
      const res = await axios.get('https://'+ currentDomain + '/api/method/logout')
      props.navigation.navigate("Login")
      dispatch(logout())
    } catch (error) {
      console.log(error)
    }

}
const select = (selectedItem, index) => {
                    
  Alert.alert('Done', 'language is set to '+selectedItem)
  dispatch(saveLang(selectedItem))
}


const backActionHandler = () => {
  Alert.alert("Exit !", "Are you sure to exit Slnee Mobile ?", [
    {
      text: "Cancel",
      onPress: () => null,
      style: "cancel"
    },
    { text: "Yes", onPress: () => BackHandler.exitApp()
    () }
  ]);
  return true;
};   
useEffect(() => {
  BackHandler.addEventListener("hardwareBackPress", backActionHandler);

  return () =>
   
    BackHandler.removeEventListener("hardwareBackPress", backActionHandler);



}, []);

  const [fontsLoaded] = useFonts({
    Mynerve: require("../assets/Fonts/MaShanZheng.ttf"),
    Merry: require("../assets/Fonts/MerriweatherLight.ttf"),
    Grand: require("../assets/Fonts/JustMeAgainDownHere.ttf"),
    Arabic: require("../assets/Fonts/GE_SS_Unique_Light.otf"),
  });

  const onLayoutRootView = useCallback(async () => {
    if (fontsLoaded) {
      await SplashScreen.hideAsync();
    }
  }, [fontsLoaded]);

  if (!fontsLoaded) {
    return null;
  }else if(currentUser) {
  return (
    <SafeAreaView style={{ flex: 1, height: windowHeight, width: windowWidth }}>
      <View
        style={{
          backgroundColor: "white",
          height: "100%",
          width: "100%",
          position: "relative",
        }}
      >
        <View
          style={{
            height: 120,
            width: windowWidth,
            backgroundColor: "#FA9884",
            position: "relative",
          }}
        >
          <View
            style={{
              position: "absolute",
              zIndex: 999,
              top: 150,
              bottom: 0,
              left: 0,
              right: 0,
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <Image
              style={{
                resizeMode: "contain",
                width: 100,
                height: 100,
                borderRadius: 50,
              }}
              source={require("../assets/man.png")}
            />
          </View>

          <Svg height={280} width={windowWidth} viewBox="0 0 1440 320">
            <Path
              fill="#FA9884"
              d="M0,192L60,170.7C120,149,240,107,360,112C480,117,600,171,720,197.3C840,224,960,224,1080,208C1200,192,1320,160,1380,144L1440,128L1440,0L1380,0C1320,0,1200,0,1080,0C960,0,840,0,720,0C600,0,480,0,360,0C240,0,120,0,60,0L0,0Z"
            />
          </Svg>
        </View>
        <ScrollView
          style={{
            position: "absolute",
            top: 225,
            left: 0,
            right: 0,
            height: "100%",
          
          }}
          contentContainerStyle={{  justifyContent: "center",
          alignItems: "center"}}
        >
          <View style={{ marginBottom: 25 }}>
            <Text
              style={{
                fontFamily: "Merry",
                fontSize: 25,
                color: "#FA9884",

                letterSpacing: 1,
                textAlign: "center",
              }}
            >
              {currentUser.full_name}
            </Text>
          </View>
          <View style={{ marginTop: 25 }}>
            <Text
              style={{
                fontFamily: "Merry",
                fontSize: 18,
                color: "#FA9884",

                letterSpacing: 1,
                textAlign: "center",
              }}
            >
              Your Current Domain is :{" "}
            </Text>
            <Text
              style={{
                fontFamily: "Merry",
                fontSize: 16,
                color: "#505050",
                marginTop: 25,
                letterSpacing: 1,
                textAlign: "center",
              }}
            >
              {currentDomain}{" "}
            </Text>

            <Text
              style={{
                fontFamily: "Merry",
                fontSize: 18,
                color: "#FA9884",
                marginTop: 25,
                letterSpacing: 1,
                textAlign: "center",
              }}
            >
              Your Current Session Expires On :{" "}
            </Text>
            <Text
              style={{
                fontFamily: "Merry",
                fontSize: 16,
                color: "#505050",
                marginTop: 25,
                letterSpacing: 1,
                textAlign: "center",
              }}
            >
              {currentUser.cookieExpiresDate}{" "}
            </Text>
            <View  style={{flexDirection: "row", marginTop: 20, alignItems: 'center', justifyContent: "center", gap: 20}}>
              <Text  style={{
                fontFamily: "Merry",
                fontSize: 18,
                color: "#FA9884",

                letterSpacing: 1,
                textAlign: "center",
              }} >Language</Text>
              <SelectDropdown
            
                  buttonStyle={{ width: windowWidth * 0.4 }}
                  data={['English', 'Arabic']}
                  onSelect={select}
                  defaultValue={"English"}
                />
            </View>
          </View>
          <Button onPress={handleLogOut}  style={{width: 175, marginTop: 50}} mode='contained' >Log Out</Button>
        </ScrollView>
       
      </View>
    </SafeAreaView>
  );
  }
  else {
    navigation.navigate("Login");
  }
};

export default DomainScreen;
